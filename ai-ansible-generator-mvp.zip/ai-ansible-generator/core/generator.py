from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from core.specification import RequirementSpec

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "templates"

def generate_project(spec: RequirementSpec) -> dict[str, str]:
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR), trim_blocks=True, lstrip_blocks=True)
    playbook = env.get_template("playbook.yml.j2").render(spec=spec)\n    playbook = playbook.replace("  tasks:\\n", f"  vars:\\n    filesystem_threshold: {spec.threshold}\\n\\n  tasks:\\n", 1)
    variables = f"filesystem_threshold: {spec.threshold}\ndiagnostic_only: true\n"
    readme = (
        f"# {spec.name}\n\n{spec.description}\n\n"
        f"- Plataforma: RHEL\n- Versiones: {', '.join(spec.versions)}\n"
        f"- Umbral: {spec.threshold}%\n- Modo: diagnóstico, sin modificaciones.\n\n"
        "Revise inventario, permisos y compatibilidad antes de ejecutar. "
        "Valide con ansible-playbook --syntax-check en desarrollo.\n"
    )
    return {
        "playbooks/site.yml": playbook,
        "group_vars/all.yml": variables,
        "README.md": readme,
    }
