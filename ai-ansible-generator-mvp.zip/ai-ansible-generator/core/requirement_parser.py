import re
from core.specification import RequirementSpec

def parse_natural_language(text: str) -> RequirementSpec:
    """Parser provisional por reglas; se ampliará con un modelo de IA."""
    normalized = text.lower()
    if not any(word in normalized for word in ("filesystem", "filesystems", "file system", "sistema de archivos")):
        raise ValueError("Esta primera versión reconoce diagnósticos de filesystems.")
    if any(word in normalized for word in ("eliminar", "borrar", "limpiar", "remediar", "modificar", "corregir")):
        raise ValueError("El requerimiento parece solicitar cambios. El MVP solo admite diagnóstico.")
    match = re.search(r"(\d{1,3})\s*%", normalized)
    threshold = int(match.group(1)) if match else 85
    if not 1 <= threshold <= 100:
        raise ValueError("El umbral debe estar entre 1 y 100.")
    versions = []
    if "rhel 8" in normalized or "rhel 8/9" in normalized or "rhel 8 y 9" in normalized:
        versions.append("RHEL 8")
    if "rhel 9" in normalized or "rhel 8/9" in normalized or "rhel 8 y 9" in normalized:
        versions.append("RHEL 9")
    if not versions:
        versions = ["RHEL 8", "RHEL 9"]
    return RequirementSpec(
        name="filesystem_diagnostics", description=text.strip(), versions=versions,
        threshold=threshold, mode="diagnostic", remediation_allowed=False
    )
