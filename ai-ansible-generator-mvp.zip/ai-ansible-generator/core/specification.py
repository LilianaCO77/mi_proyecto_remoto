import re
from pydantic import BaseModel, Field, field_validator

class RequirementSpec(BaseModel):
    name: str = Field(min_length=3, max_length=50)
    description: str = Field(min_length=10)
    platform: str = "rhel"
    versions: list[str] = Field(min_length=1)
    threshold: int = Field(default=85, ge=1, le=100)
    mode: str = "diagnostic"
    remediation_allowed: bool = False

    @field_validator("name")
    @classmethod
    def safe_name(cls, value):
        if not re.fullmatch(r"[a-z][a-z0-9_]*", value):
            raise ValueError("Use minúsculas, números y guion bajo; comience con una letra.")
        return value

    @field_validator("versions")
    @classmethod
    def supported_versions(cls, value):
        if not set(value).issubset({"RHEL 8", "RHEL 9"}):
            raise ValueError("El MVP inicial admite RHEL 8 y RHEL 9.")
        return value

    @field_validator("mode")
    @classmethod
    def diagnostic_only(cls, value):
        if value != "diagnostic":
            raise ValueError("El MVP inicial solo admite diagnóstico.")
        return value

    @field_validator("remediation_allowed")
    @classmethod
    def no_remediation(cls, value):
        if value:
            raise ValueError("La remediación está deshabilitada en esta versión.")
        return value
