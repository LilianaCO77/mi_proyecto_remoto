import io
import zipfile
import streamlit as st
from core.specification import RequirementSpec
from core.generator import generate_project
from core.requirement_parser import parse_natural_language

st.set_page_config(page_title="AI Ansible Generator", page_icon="⚙️", layout="wide")
st.title("AI Ansible Generator")
st.caption("De requerimientos de infraestructura a proyectos Ansible revisables")

mode = st.radio("Modalidad", ["Lenguaje natural", "Formulario guiado"], horizontal=True)

if mode == "Lenguaje natural":
    request = st.text_area(
        "Describa el requerimiento",
        placeholder="Verificar filesystems en RHEL 8 y 9. Alertar sobre 85% de uso. No realizar modificaciones.",
        height=130,
    )
    if st.button("Interpretar requerimiento", type="primary", disabled=not request.strip()):
        try:
            st.session_state["spec"] = parse_natural_language(request)
        except ValueError as exc:
            st.error(str(exc))
else:
    with st.form("guided"):
        name = st.text_input("Nombre", "filesystem_diagnostics")
        description = st.text_area("Descripción", "Diagnóstico de utilización de filesystems.")
        threshold = st.slider("Umbral (%)", 1, 100, 85)
        versions = st.multiselect("Versiones", ["RHEL 8", "RHEL 9"], ["RHEL 8", "RHEL 9"])
        submitted = st.form_submit_button("Crear especificación", type="primary")
        if submitted:
            try:
                st.session_state["spec"] = RequirementSpec(
                    name=name, description=description, versions=versions,
                    threshold=threshold, mode="diagnostic", remediation_allowed=False
                )
            except Exception as exc:
                st.error(str(exc))

spec = st.session_state.get("spec")
if spec:
    st.subheader("1. Especificación para revisión")
    st.json(spec.model_dump())
    st.warning("Modo diagnóstico solamente. No se ejecutan cambios ni conexiones a servidores.")
    if st.button("Generar proyecto Ansible", type="primary"):
        st.session_state["project_files"] = generate_project(spec)

project_files = st.session_state.get("project_files")
if project_files:
    st.subheader("2. Proyecto generado")
    for filename, content in project_files.items():
        with st.expander(filename, expanded=filename.endswith(".yml")):
            st.code(content, language="yaml" if filename.endswith((".yml", ".yaml")) else "markdown")
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename, content in project_files.items():
            archive.writestr(filename, content)
    st.download_button("Descargar proyecto ZIP", buffer.getvalue(),
                       file_name=f"{spec.name}.zip", mime="application/zip")
