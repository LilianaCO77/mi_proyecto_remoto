def prepare_aap_project(*args, **kwargs):
    raise NotImplementedError("La integración AAP se implementará en una etapa posterior.")
