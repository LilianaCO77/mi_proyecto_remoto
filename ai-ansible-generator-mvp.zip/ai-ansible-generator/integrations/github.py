def publish_project(*args, **kwargs):
    raise NotImplementedError("La publicación GitHub se implementará en una etapa posterior.")
